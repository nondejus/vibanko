from json import loads, dumps, JSONEncodeException, JSONDecodeException
from proxy import ServiceProxy, JSONRPCException
