from authproxy import AuthServiceProxy as ServiceProxy, JSONRPCException
