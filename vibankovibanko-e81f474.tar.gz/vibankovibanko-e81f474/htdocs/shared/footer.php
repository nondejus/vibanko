<div style='clear: both;'></div>
</div>
<footer>
    <a href='faq.php'>FAQ</a> | 
    <a href='about-us.php'>About us</a>
</footer>
</body>
</html>

